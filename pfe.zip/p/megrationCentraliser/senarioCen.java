package p.megrationCentraliser;


import java.util.ArrayList;
import java.util.Calendar;
import java.util.LinkedList;
import java.util.List;

import org.cloudbus.cloudsim.Host;
import org.cloudbus.cloudsim.Log;
import org.cloudbus.cloudsim.Pe;
import org.cloudbus.cloudsim.Storage;
import org.cloudbus.cloudsim.core.CloudSim;
import org.cloudbus.cloudsim.core.SimEntity;
import org.cloudbus.cloudsim.power.PowerHost;
import org.cloudbus.cloudsim.provisioners.RamProvisionerSimple;
import org.cloudbus.cloudsim.sdn.overbooking.BwProvisionerOverbooking;
import org.cloudbus.cloudsim.sdn.overbooking.PeProvisionerOverbooking;
import org.fog.application.AppEdge;
import org.fog.application.AppLoop;
import org.fog.application.AppModule;
import org.fog.application.Application;
import org.fog.application.selectivity.FractionalSelectivity;
import org.fog.entities.Actuator;
import org.fog.entities.FogBroker;
import org.fog.entities.FogDevice;
import org.fog.entities.FogDeviceCharacteristics;
import org.fog.entities.Sensor;
import org.fog.entities.Tuple;
import org.fog.placement.Controller;
import org.fog.placement.ModuleMapping;
import org.fog.placement.ModulePlacementEdgewards;
import org.fog.placement.ModulePlacementMapping;
import org.fog.policy.AppModuleAllocationPolicy;
import org.fog.scheduler.StreamOperatorScheduler;
import org.fog.utils.Config;
import org.fog.utils.FogLinearPowerModel;
import org.fog.utils.FogUtils;
import org.fog.utils.TimeKeeper;
import org.fog.utils.distribution.DeterministicDistribution;

import p.megration.latancy;



/*
 * Topologie vide
 */
public class senarioCen {
	static List<FogDevice> fogDevices = new ArrayList<FogDevice>();
	static List<Sensor> sensors = new ArrayList<Sensor>();
	static List<Actuator> actuators = new ArrayList<Actuator>();
	
	
	public static latancy Latancy;

	
	public static double reqd;
	public static double reqv;
	public static double rspd;
	public static double rspv;
	
	
	//static List<Data> dataList = new ArrayList<Data>();
	//static Blockchain blockchain;
	static List<SmartNoeud> Smartrouter= new ArrayList<SmartNoeud>();
	
	

	
	public static void main(String[] args) {
		
		

		
		try {
			//DEBUT PARTIE_QUI_CHANGE_PAS_1
			
			Log.disable();
			Calendar calendar = Calendar.getInstance();
			CloudSim.init(1, calendar, false);
			String appId = "app1";
			FogBroker broker = new FogBroker("broker");
			Application application = createApplication(appId, broker.getId());
			application.setUserId(broker.getId());
			Controller controller = null;
			ModuleMapping moduleMapping = ModuleMapping.createModuleMapping(); //Nous avons d�plac� cette instruction pour pouvoir positionner les modules au fur et � mesure de la cr�action des noeuds
			//FIN PARTIE_QUI_CHANGE_PAS_1
			
			//DEBUT CREATION_DE_LA_TOPOLOGIE
			
			//creation du cloud:
			
			SmartNoeud cloud = createSmartNoeud("cloud", 4000, 10000, 100, 10000, 0, 0.01, 20, 10,100000);
			cloud.setParentId(-1);
			fogDevices.add(cloud);
			moduleMapping.addModuleToDevice("Module_Cloud", "cloud"); //Syntaxe d'ajout de modules aux noeuds
			
			
			
			
			
			
			ArrayList<Integer> listeA = new ArrayList<Integer>();
			ArrayList<Integer> listeB = new ArrayList<Integer>();
			
//Cr�ez vos noeuds Fog et objets/capteurs ici:
					
			//cr�ation de level 1
			for(int j=1;j<=Config.nbrefog;j++) {
				String RId = "fog"+1+j;
				SmartNoeud router= createSmartNoeud(RId, 3000, 8000, 10000, 10000, 1, 0.0, 107.339, 83.4333,500000);
	
					fogDevices.add(router);
					router.setUplinkLatency(2);
					router.setParentId(cloud.getId());
					listeA.add(router.getId());
				//	moduleMapping.addModuleToDevice("module_fog3", RId);
					
				}
			//cr�ation des autres level 
			
			int k =0;
			int l=0;
			for(int i=2;i<=Config.nbrlevel;i++) {
				listeB = (ArrayList<Integer>) listeA.clone();
				listeA.clear();
				k=k+2000;
				l=l+500;
				
				for(int j=1;j<=Config.nbrefog;j++) {
					
					String RId = "fog"+i+j;
					SmartNoeud router= createSmartNoeud(RId, 2500, 6000, 2000, 2000, i, 0.0, 107.339, 83.4333,128000);
					
					router.setParentId(listeB.get(j-1));
					if (j!=1) {
					router.setParentId2(listeB.get(j-2));
					}
					if (j!=Config.nbrefog) {
					router.setParentId3(listeB.get(j));}

					listeA.add(router.getId());
					
					/*System.out.println(router.getId());
					System.out.println(RId);*/
					
						fogDevices.add(router);
						router.setUplinkLatency(2);
						if (i==Config.nbrlevel) {
						if(j%2==0) {
							moduleMapping.addModuleToDevice("module_data", RId);
							moduleMapping.addModuleToDevice("module_notif", RId);
							
							}
							else {
							moduleMapping.addModuleToDevice("module_video", RId);
							moduleMapping.addModuleToDevice("module_notif", RId);
							}
						moduleMapping.addModuleToDevice("module_fog1", RId);

						}
						else {
						moduleMapping.addModuleToDevice("module_migration", RId);

						}
						router.SetModulleMapping(moduleMapping);
						Smartrouter.add(router);
						//router.SetDataList(dataList);
						//System.out.println("tyahai" +dataList);

					}
				
				
				
				}
			
			
		//cr�ation d'une boucle pour les objet 	
			
			
			
			for(int j=1;j<=Config.nbrefog;j++) {
				String OId = "obj-RasB-Pi3"+j;
				FogDevice obj = createFogDevice(OId, 2000, 2000, 1000, 5000, Config.nbrlevel+1, 0, 87.53, 82.44,32000);
				obj.setParentId(listeA.get(j-1));
				
					
				
				fogDevices.add(obj);

				String SId ="capteur"+j;
				Sensor sensor1 = new Sensor("captureData", "data", broker.getId(), appId, new DeterministicDistribution(Config.intervalTuple)); // inter-transmission time of camera (sensor) follows a deterministic distribution
				Sensor sensor2 = new Sensor("captureVideo", "video", broker.getId(), appId, new DeterministicDistribution(Config.intervalTuple)); // inter-transmission time of camera (sensor) follows a deterministic distribution

				sensors.add(sensor1);
				sensors.add(sensor2);
				sensor1.setGatewayDeviceId(obj.getId());
				sensor1.setLatency(1.0); 
				sensor2.setGatewayDeviceId(obj.getId());
				sensor2.setLatency(1.0); 
			//	moduleMapping.addModuleToDevice("module_fog1", OId);

					
				}
			
			System.out.println(moduleMapping.getModuleMapping());
			
			//System.out.println(application.getModules().get(4).getName());
			//System.out.println(fogDevices.get(2).getName());
		
		
			int r=0;
			for(int j=0;j<=(application.getModules().size())-1;j++) {
			for(int i=0;i<=(fogDevices.size())-1;i++) {
				if(moduleMapping.getModuleMapping().containsKey(fogDevices.get(i).getName())) {
				if(moduleMapping.getModuleMapping().get(fogDevices.get(i).getName()).contains(application.getModules().get(j).getName())) {
					
				//	Data data  = new Data();
					
					/*data.DeviceName = fogDevices.get(i).getName();
					data.ID = fogDevices.get(i).getId();
					data.ModulleName = application.getModules().get(j).getName();*/
					//System.out.println(fogDevices.get(i).getName()+application.getModules().get(j).getName());
					//System.out.println(data.DeviceName+data.ModulleName);
				//	dataList.add(data);
				//	System.out.println(dataList.get(0).DeviceName);

				/*	for(int s=0;s<=(dataList.size())-1;s++) {
						 System.out.println("************* "+dataList.get(s).DeviceName+dataList.get(s).ModulleName);
						 }*/
					 
					 r++;
					//data.DeviceName = "dsqdqsd";
					//data.ModulleName = "dsqdqsd";
					
					
				}
				}
			
			}
			}
			latancy.setFogDevices (fogDevices);

			for(int i=0;i<=fogDevices.size()-1;i++)
			 System.out.println(fogDevices.get(i).getName()+" "+fogDevices.get(i).getId());

			/* Blockchain blockchain = new Blockchain(1);
			 blockchain.addBlock(blockchain.newBlock(dataList));
			 for(int i=0;i<=(dataList.size())-1;i++) {
			 System.out.println(dataList.get(i).DeviceName+dataList.get(i).ModulleName);
			 }
			 
			 System.out.println("\nBlockchain valid ? " + blockchain.isBlockChainValid());
			 System.out.println(blockchain);
			for(int i=0;i<=(Smartrouter.size())-1;i++) {
			Smartrouter.get(i).SetDataList(dataList);
			Smartrouter.get(i).SetBlockchain(blockchain);
			}*/
			

			
			
			
			
			
			
			
			
			
			

			


			//PlacementModule(fogDevices,"module_fog1");
			List<AppModule> module = application.getModules();
			//new ConsomationDiplay(fogDevices,module,moduleMapping,nbrefog);
			//new PlacementModule(fogDevices,module,moduleMapping,nbrefog);
		//	new ConsomationDisplay(fogDevices,module,moduleMapping, nbrefog);
			//new ConsomationDisplay(fogDevices,module,moduleMapping,nbrefog);
			//FIN CREATION_DE_LA_TOPOLOGIE
			//DEBUT PARTIE_QUI_CHANGE_PAS_2
			
			controller = new Controller("master-controller", fogDevices, sensors, actuators);
			controller.submitApplication(application,(new ModulePlacementEdgewards(fogDevices, sensors, actuators, application, moduleMapping)));
			
			
			TimeKeeper.getInstance().setSimulationStartTime(Calendar.getInstance().getTimeInMillis());
			CloudSim.startSimulation();
			//CloudSim.stopSimulation(); //inutile
			//FIN PARTIE_QUI_CHANGE_PAS_2

			}
		catch (Exception e) {
			e.printStackTrace();
			Log.printLine("Unwanted errors happen");
		}
		
		
		
		
		

	}
	
		// TODO Auto-generated method stub
		
	
	//Placement de VM 
	/*static void PlacementModule(List<FogDevice> fogDevices, String moduleToPlace) {
		ModuleMapping moduleMapping = null;
		// TODO Auto-generated method stub
		int a = fogDevices.size();
		String nameDevice;
		for(int i=1; i==a ;i++){
			nameDevice=((SimEntity) fogDevices).getName();
		moduleMapping.addModuleToDevice(moduleToPlace,nameDevice );
		}
	}*/
	//Cr�er un FogDevice standard (identique � celle des exemples):
	private static FogDevice createFogDevice(String nodeName, long mips,
			int ram, long upBw, long downBw, int level, double ratePerMips, double busyPower, double idlePower, long Disk) {
		
		List<Pe> peList = new ArrayList<Pe>();

		// 3. Create PEs and add these into a list.
		peList.add(new Pe(0, new PeProvisionerOverbooking(mips))); // need to store Pe id and MIPS Rating

		int hostId = FogUtils.generateEntityId();
		long storage = Disk; // host storage
		int bw = 10000;

		PowerHost host = new PowerHost(
				
				hostId,
				new RamProvisionerSimple(ram),
				new BwProvisionerOverbooking(bw),
				storage,
				peList,
				new StreamOperatorScheduler(peList),
				new FogLinearPowerModel(busyPower, idlePower)
			);

		List<Host> hostList = new ArrayList<Host>();
		hostList.add(host);

		String arch = "x86"; // system architecture
		String os = "Linux"; // operating system
		String vmm = "Xen";
		double time_zone = 10.0; // time zone this resource located
		double cost = 3.0; // the cost of using processing in this resource
		double costPerMem = 0.05; // the cost of using memory in this resource
		double costPerStorage = 0.001; // the cost of using storage in this resource
		double costPerBw = 0.0; // the cost of using bw in this resource
		LinkedList<Storage> storageList = new LinkedList<Storage>();

		FogDeviceCharacteristics characteristics = new FogDeviceCharacteristics(
				arch, os, vmm, host, time_zone, cost, costPerMem,
				costPerStorage, costPerBw);

		FogDevice fogdevice = null;
		try {
			fogdevice = new FogDevice(nodeName, characteristics, 
					new AppModuleAllocationPolicy(hostList), storageList, 10, upBw, downBw, 0, ratePerMips);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		fogdevice.setLevel(level);
		
		return fogdevice;
	}
	private static SmartNoeud createSmartNoeud(String nodeName, long mips,
			int ram, long upBw, long downBw, int level, double ratePerMips, double busyPower, double idlePower, long Disk) {
		
		List<Pe> peList = new ArrayList<Pe>();

		// 3. Create PEs and add these into a list.
		peList.add(new Pe(0, new PeProvisionerOverbooking(mips))); // need to store Pe id and MIPS Rating

		int hostId = FogUtils.generateEntityId();
		long storage = Disk; // host storage
		int bw = 10000;

		PowerHost host = new PowerHost(
				hostId,
				new RamProvisionerSimple(ram),
				new BwProvisionerOverbooking(bw),
				storage,
				peList,
				new StreamOperatorScheduler(peList),
				new FogLinearPowerModel(busyPower, idlePower)
			);

		List<Host> hostList = new ArrayList<Host>();
		hostList.add(host);

		String arch = "x86"; // system architecture
		String os = "Linux"; // operating system
		String vmm = "Xen";
		double time_zone = 10.0; // time zone this resource located
		double cost = 3.0; // the cost of using processing in this resource
		double costPerMem = 0.05; // the cost of using memory in this resource
		double costPerStorage = 0.001; // the cost of using storage in this resource
		double costPerBw = 0.0; // the cost of using bw in this resource
		LinkedList<Storage> storageList = new LinkedList<Storage>();

		FogDeviceCharacteristics characteristics = new FogDeviceCharacteristics(
				arch, os, vmm, host, time_zone, cost, costPerMem,
				costPerStorage, costPerBw);

		SmartNoeud fogdevice = null;
		try {
			fogdevice = new SmartNoeud(nodeName, characteristics, 
					new AppModuleAllocationPolicy(hostList), storageList, 10, upBw, downBw, 0, ratePerMips);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		fogdevice.setLevel(level);
		return fogdevice;
	}
	
	//Cr�er l'application:
	//VOIR EXEMPLES POUR LA SYNTAXE
	private static Application createApplication(String appId, int userId){
		Application application = Application.createApplication(appId, userId);
		
		//Cr�ation des modules:
		//int nbrlevel = 20;
		application.addAppModule("Module_Cloud", 10);
		application.addAppModule("module_data", 500, 500, Config.dataSize, 100);
		application.addAppModule("module_video", 1000, 1000, Config.videoSize, 100);
		application.addAppModule("module_migration", 100, 100, 100, 10);
		application.addAppModule("module_fog1", 100, 100, 100, 10);
		application.addAppModule("module_notif", 100, 100, 100, 10);
		//application.addAppModule("module_fog3", 900, 500, 128, 800);
		//application.addAppModule("module_fog4", 6000, 2000, 4000, 800);
		
		/*for(int i=2;i<=nbrlevel ;i++) {
			String O = "module_fog"+i;
			application.addAppModule(O, 10);
		}*/


		
		//Ajout des liens entre les modules:
		/*
		application.addAppEdge("tuple1", "module_fog3", 1000, 2000, "tuple1", Tuple.UP, AppEdge.SENSOR);
		application.addAppEdge("module_fog3", "module_fog2", 200, 1500, "compression-data3", Tuple.UP, AppEdge.MODULE);
		application.addAppEdge("module_fog2", "module_fog1", 200, 1500, "compression-data2", Tuple.UP, AppEdge.MODULE);
		application.addAppEdge("module_fog1", "Module_Cloud", 200, 1000, "compression-data1", Tuple.UP, AppEdge.MODULE);
		*/
		
		
		
		//int tailleTuple=100000;
		application.addAppEdge("data", "module_fog1", 1000, 50, "data", Tuple.UP, AppEdge.SENSOR);
		application.addAppEdge("video", "module_fog1", 1000, 100, "video", Tuple.UP, AppEdge.SENSOR);
		application.addAppEdge("module_fog1", "Module_Cloud", 1000, 5, "requestVMvideo", Tuple.UP, AppEdge.MODULE);
		application.addAppEdge("module_fog1", "Module_Cloud", 1000, 5, "requestVMdata", Tuple.UP, AppEdge.MODULE);
		
		
		application.addAppEdge("Module_Cloud", "module_fog1", 1000, Config.videoSize, "rresponseVMvideo", Tuple.DOWN, AppEdge.MODULE);
		application.addAppEdge("Module_Cloud", "module_fog1", 1000, Config.dataSize, "rresponseVMdata", Tuple.DOWN, AppEdge.MODULE);
		
	
		
		//application.addAppEdge("module_fog1", "module_video", 1000, tailleTuple, "video1", Tuple.UP, AppEdge.MODULE);
		//application.addAppEdge("module_fog1", "module_data", 1000, tailleTuple, "data1", Tuple.UP, AppEdge.MODULE);
		
		//application.addAppEdge("module_data", "module_migration", 1000, tailleTuple, "compression-data", Tuple.UP, AppEdge.MODULE);
		//application.addAppEdge("module_video", "module_migration", 1000, tailleTuple, "compression-video", Tuple.UP, AppEdge.MODULE);
		//application.addAppEdge("module_video", "module_video", 1000, tailleTuple, "requestVMvideo", Tuple.UP, AppEdge.MODULE);
		//application.addAppEdge("module_fog1", "module_data", 1000, tailleTuple, "requestVMdata", Tuple.UP, AppEdge.MODULE);
		/*application.addAppEdge("module_migration", "module_fog1", 1000, tailleTuple, "routageRequestVMvideo", Tuple.DOWN, AppEdge.MODULE);
		application.addAppEdge("module_migration", "module_fog1", 1000, tailleTuple, "routageRequestVMdata", Tuple.DOWN, AppEdge.MODULE);*/
		
		

		//application.addAppEdge("module_fog1", "module_fog2", 1000, tailleTuple*0.8, "compression-data1", Tuple.UP, AppEdge.MODULE);
		//application.addAppEdge("module_fog2", "module_fog3", 1000, tailleTuple*0.8*0.8, "compression-data2", Tuple.UP, AppEdge.MODULE);
		//application.addAppEdge("module_fog3", "module_fog1", 1000, 100, "ACK", Tuple.DOWN, AppEdge.MODULE);
		//application.addAppEdge("module_fog3", "Module_Cloud", 1000, tailleTuple*0.8*0.8, "Stockage", Tuple.UP, AppEdge.MODULE); 
		
		//D�finition du taux d'�mission de chaque Tuple r�sultant par Module:
		//application.addTupleMapping("module_data", "data1", "compression-data", new FractionalSelectivity(1.0));
		//application.addTupleMapping("module_video", "video1", "compression-video", new FractionalSelectivity(1.0));
		
		application.addTupleMapping("module_fog1", "video", "requestVMvideo", new FractionalSelectivity(1.0));
		application.addTupleMapping("module_fog1", "data", "requestVMdata", new FractionalSelectivity(1.0));

		application.addTupleMapping("Module_Cloud", "requestVMvideo", "rresponseVMvideo", new FractionalSelectivity(1.0));
		application.addTupleMapping("Module_Cloud", "requestVMdata", "rresponseVMdata", new FractionalSelectivity(1.0));
		
		
	


		//application.addTupleMapping("module_fog1", "data", "data1", new FractionalSelectivity(1.0));
		//application.addTupleMapping("module_fog1", "video", "video1", new FractionalSelectivity(1.0));
		
		
		
		
		/*application.addTupleMapping("module_migration", "requestVMdata", "routageRequestVMvideo", new FractionalSelectivity(1.0));
		application.addTupleMapping("module_migration", "requestVMvideo", "routageRequestVMdata", new FractionalSelectivity(1.0));*/

		//application.addTupleMapping("module_fog1", "tuple1", "broadCast", new FractionalSelectivity(1.0));
		//application.addTupleMapping("module_fog2", "compression-data1", "compression-data2", new FractionalSelectivity(1.0));
		//application.addTupleMapping("module_fog3", "compression-data2", "ACK", new FractionalSelectivity(1.0));
		//application.addTupleMapping("module_fog3", "compression-data2", "Stockage", new FractionalSelectivity(1.0));
		
		System.out.println(application.getEdges().get(1).getDestination());

		
		
		//application.addTupleMapping("module_fog", "tuple1", "compression-data", new FractionalSelectivity(1.0));
		
		
		String A ="module_fog";
		//final AppLoop loop1 = new AppLoop(new ArrayList<String>(){{add("module_fog1");add("module_fog2");add("module_fog3");add("module_fog1");}});
		//List<AppLoop> loops = new ArrayList<AppLoop>(){{add(loop1);}};
		
		//application.setLoops(loops);
		

		

		return application;
	}
	
	public static void setReqd(double i) {
		reqd = i;
	}
	public static void setReqv(double i) {
		reqv = i;
	}
	public static void setRspd(double i) {
		rspd = i;
	}
	public static void setRspv(double i) {
		rspv = i;
	}
}

