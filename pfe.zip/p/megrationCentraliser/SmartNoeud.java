package p.megrationCentraliser;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Queue;

import org.cloudbus.cloudsim.Cloudlet;
import org.cloudbus.cloudsim.Host;
import org.cloudbus.cloudsim.Log;
import org.cloudbus.cloudsim.Storage;
import org.cloudbus.cloudsim.Vm;
import org.cloudbus.cloudsim.VmAllocationPolicy;
import org.cloudbus.cloudsim.core.CloudSim;
import org.cloudbus.cloudsim.core.CloudSimTags;
import org.cloudbus.cloudsim.core.SimEvent;
import org.cloudbus.cloudsim.power.PowerHost;
import org.fog.application.AppModule;
import org.fog.application.Application;
import org.fog.entities.FogDevice;
import org.fog.entities.FogDeviceCharacteristics;
import org.fog.entities.Tuple;
import org.fog.utils.Config;
import org.fog.utils.FogEvents;
import org.fog.utils.FogUtils;
import org.fog.utils.Logger;
import org.fog.utils.NetworkUsageMonitor;
import org.fog.utils.TimeKeeper;

import correction.topologie3.Personnage;
import p.megration.senario;

import org.fog.placement.ModuleMapping;


/**
 * Cette classe permet d'instancier un noeud Fog intelligent permettant d'effetuer les traitements d�crits pas l'�nonc� de la topologie 3.
 * Les traitements effectu�s par ce noeud sont les suivants:
 * 1- G�rer les commandes des objets enfants. C'est � dire:
 *    a- V�rifier si le noeud n'est pas bloqu� avant l'ex�cution du tuple COMMANDE.
 *    b- S'il n'est pas bloqu�, ex�cuter le tuple COMMANDE.
 *    c- Apr�s la fin de l'ex�cution du tuple, modifier la position du Personnage associ� � cet objet.
 *    d- V�rifier que les nouvelles coordonn�es du Personnage ne d�passent pas le max.
 *    e- Si elles d�passent, r�initialiser la position et bloquer l'objet.
 *    f- Si l'objet est devenu bloqu�, un tuple BLOCK est envoy� au cloud, et la date de bloquage de l'objet est sauvegard�e dans la liste blockTimes.
 * 
 * @author TEFFAHI Oussama
 */
public class SmartNoeud extends FogDevice{
	
	
	
	ModuleMapping moduleMapping;
	
	protected int distID;
	protected int parentId2=0;
	protected int parentId3=0;
	int i=0,j=0;
	
	boolean reqV=false;
	boolean reqD=false;
	boolean rspD=false;
	boolean rspV=false;
	boolean sendRequestV=true;
	boolean sendRequestD=true;
	public static int dataTupleLose=0;
	public static int videoTupleLose=0;
	
	
	private HashMap<Integer, Personnage> listePersos = new HashMap<Integer, Personnage>(); //liste associant � chaque id d'objet enfant de ce noeud une instance de la classe Personnage. Initialement vide.
	private HashMap<Integer, Double> blockTimes = new HashMap<Integer, Double>(); //liste associant � chaque id d'objet enfant de ce noeud la date de bloquage de celui-ci s'il est actuellement bloqu�. Initialement vide.
	
	public SmartNoeud(String name, FogDeviceCharacteristics characteristics, VmAllocationPolicy vmAllocationPolicy,
			List<Storage> storageList, double schedulingInterval, double uplinkBandwidth, double downlinkBandwidth,
			double uplinkLatency, double ratePerMips) throws Exception {
		super(name, characteristics, vmAllocationPolicy, storageList, schedulingInterval, uplinkBandwidth, downlinkBandwidth,
				uplinkLatency, ratePerMips);	
		
		//ModuleMapping moduleMapping;
		
		
		
		
	}
	
	/**
	 * Ici le noeud v�rifie si l'objet associ� au tuple COMMANDE re�u est bloqu� ou non.
	 * - S'il est bloqu�, le tuple COMMANDE est ignor�.
	 * - S'il n'est pas bloqu�, ou s'il est bloqu� mais que la p�riode de bloquage est �coul�e, le tuple COMMANDE est ex�cut� normalement.
	 * Les modifications commencent � la ligne 108.
	 */
	
	protected void sendUpFreeLink(Tuple tuple,String parent ){
		double networkDelay = tuple.getCloudletFileSize()/getUplinkBandwidth();
		
		switch (parent) {
		case "up": 
			setNorthLinkBusy(true);
			send(getId(), networkDelay, FogEvents.UPDATE_NORTH_TUPLE_QUEUE);
			send(parentId, networkDelay+getUplinkLatency(), FogEvents.TUPLE_ARRIVAL, tuple);
			NetworkUsageMonitor.sendingTuple(getUplinkLatency(), tuple.getCloudletFileSize());
			//System.out.println("envoi tuple  ("+tuple.getTupleType()+ ")  from  "+this.getId()+"  to  "+parentId);

			break;
		case "left":
			setNorthLinkBusyLeft(true);
			send(getId(), networkDelay, FogEvents.UPDATE_NORTH_TUPLE_QUEUE);
			send(parentId2, networkDelay+getUplinkLatency(), FogEvents.TUPLE_ARRIVAL, tuple);
			NetworkUsageMonitor.sendingTuple(getUplinkLatency(), tuple.getCloudletFileSize());
			//System.out.println("envoi tuple  ("+tuple.getTupleType()+ ")  from  "+this.getId()+"  to  "+parentId2);
			break;
		case "right":
			setNorthLinkBusyRight(true);
			send(getId(), networkDelay, FogEvents.UPDATE_NORTH_TUPLE_QUEUE);
			send(parentId3, networkDelay+getUplinkLatency(), FogEvents.TUPLE_ARRIVAL, tuple);
			NetworkUsageMonitor.sendingTuple(getUplinkLatency(), tuple.getCloudletFileSize());
		//	System.out.println("envoi tuple  ("+tuple.getTupleType()+ ")  from  "+this.getId()+"  to  "+parentId3);

			break;
		}


	}
	
	
	protected void sendUp(Tuple tuple,String desstination){
		switch (desstination) {
		case "broadCast" : 
		//	System.out.println("////////////////////////////// broadCast  up : "+isNorthLinkBusy+" left : "+isNorthLinkBusyLeft+" right : "+isNorthLinkBusyRight);
			if(parentId > 0){
				if(!isNorthLinkBusy()){
					sendUpFreeLink(tuple,"up");
				}else{
					northTupleQueue.add(tuple);
				}
			}
			if(parentId2 > 0){
				if(!isNorthLinkBusyLeft()){
					sendUpFreeLink(tuple,"left");
				}else{
					northTupleQueueLeft.add(tuple);
				}
			}
			if(parentId3 > 0){
				if(!isNorthLinkBusyRight()){
					sendUpFreeLink(tuple,"right");
				}else{
					northTupleQueueRight.add(tuple);
				}
			}
			break;
			
		case "right" :
			
			if(parentId3 > 0){
				if(!isNorthLinkBusyRight()){
					sendUpFreeLink(tuple,"right");
				}else{
					northTupleQueueRight.add(tuple);
				}
			}
			break;
			
		case "left":
			if(parentId2 > 0){
				if(!isNorthLinkBusyLeft()){
					sendUpFreeLink(tuple,"left");
				}else{
					northTupleQueueLeft.add(tuple);
				}
			}
			
			break;
			
		}
		
	}
	/*protected void sendDown(Tuple tuple,String desstination){
		if (desstination=="broadCastRight") {
		//	System.out.println("////////////////////////////// broadCast  up : "+isNorthLinkBusy+" left : "+isNorthLinkBusyLeft+" right : "+isNorthLinkBusyRight);
			if(parentId > 0){
				if(!isNorthLinkBusy()){
					sendDownFreeLink(tuple,tuple);
				}else{
					northTupleQueue.add(tuple);
				}
			}
			
			if(parentId3 > 0){
				if(!isNorthLinkBusyRight()){
					sendDownFreeLink(tuple,"right");
				}else{
					northTupleQueueRight.add(tuple);
				}
			}
		}
		if (desstination=="broadCastLeft") {
			//	System.out.println("////////////////////////////// broadCast  up : "+isNorthLinkBusy+" left : "+isNorthLinkBusyLeft+" right : "+isNorthLinkBusyRight);
				if(parentId > 0){
					if(!isNorthLinkBusy()){
						sendDownFreeLink(tuple,"up");
					}else{
						northTupleQueue.add(tuple);
					}
				}
				if(parentId2 > 0){
					if(!isNorthLinkBusyLeft()){
						sendDownFreeLink(tuple,"left");
					}else{
						northTupleQueueLeft.add(tuple);
					}
				}
				
			}
		
	}*/
	
	protected void processTupleArrival(SimEvent ev){

		Tuple tuple = (Tuple)ev.getData();
	//System.out.println("555555555555"+"    "+ dataList);
		if(getName().equals("cloud")){
			updateCloudTraffic();
		}
		
		/*if(getName().equals("d-0") && tuple.getTupleType().equals("_SENSOR")){
			System.out.println(++numClients);
		}*/
		Logger.debug(getName(), "Received tuple "+tuple.getCloudletId()+"with tupleType = "+tuple.getTupleType()+"\t| Source : "+
		CloudSim.getEntityName(ev.getSource())+"|Dest : "+CloudSim.getEntityName(ev.getDestination()));
		send(ev.getSource(), CloudSim.getMinTimeBetweenEvents(), FogEvents.TUPLE_ACK);
		
		if(FogUtils.appIdToGeoCoverageMap.containsKey(tuple.getAppId())){
		}
		
		if(tuple.getDirection() == Tuple.ACTUATOR){
			sendTupleToActuator(tuple);
			return;
		}
		
		if(getHost().getVmList().size() > 0){
			final AppModule operator = (AppModule)getHost().getVmList().get(0);
			if(CloudSim.clock() > 0){
				getHost().getVmScheduler().deallocatePesForVm(operator);
				getHost().getVmScheduler().allocatePesForVm(operator, new ArrayList<Double>(){
					protected static final long serialVersionUID = 1L;
				{add((double) getHost().getTotalMips());}});
				tuple.getd
			}
		}
		
		
		if(getName().equals("cloud") && tuple.getDestModuleName()==null){
			sendNow(getControllerId(), FogEvents.TUPLE_FINISHED, null);
		}
		
		
		
		//System.out.println(this.getLevel()+" 77777777777777777 "+ tuple.getTupleType()+"      "+senario.nbrlevel );
		
	if (this.getLevel()==Config.nbrlevel && tuple.getTupleType()=="requestVMdata"&& reqD==false) {
		System.out.println(tuple.getTupleType()+"     5555555555555555555  "+CloudSim.clock());
		System.out.println("time of request data and her reponse"+senarioCen.rspd+senarioCen.reqd);
		senarioCen.setReqd(CloudSim.clock());
		senarioCen.Latancy.setReqd(CloudSim.clock(),this.getName());

		System.out.println("time of request data and her reponse"+senarioCen.rspd+senarioCen.reqd);
	
		reqD=true;
	}
	if (this.getLevel()==Config.nbrlevel && tuple.getTupleType()=="rresponseVMdata"&&rspD==false) {
		System.out.println(tuple.getTupleType()+"     6666666666666666666  "+CloudSim.clock());
		senarioCen.setRspd(CloudSim.clock());
		senarioCen.Latancy.setRspd(CloudSim.clock(),this.getName());

		rspD=true;
	}
	if (this.getLevel()==Config.nbrlevel && tuple.getTupleType()=="requestVMvideo"&& reqV==false) {
		System.out.println(tuple.getTupleType()+"     88888888888888888  "+CloudSim.clock());
		senarioCen.setReqv(CloudSim.clock());
		senarioCen.Latancy.setReqv(CloudSim.clock(),this.getName());

		reqV=true;
	}
	if (this.getLevel()==Config.nbrlevel && tuple.getTupleType()=="rresponseVMvideo"&&rspV==false) {
		System.out.println(tuple.getTupleType()+"     99999999999999999  "+CloudSim.clock());
		senarioCen.setRspv(CloudSim.clock());
		senarioCen.Latancy.setRspv(CloudSim.clock(),this.getName());

		rspV=true;
	}
		if(appToModulesMap.containsKey(tuple.getAppId())){
			

			if(appToModulesMap.get(tuple.getAppId()).contains(tuple.getDestModuleName())){

				int vmId = -1;
				for(Vm vm : getHost().getVmList()){
					if(((AppModule)vm).getName().equals(tuple.getDestModuleName()))
						vmId = vm.getId();
				}
				if(vmId < 0|| (tuple.getModuleCopyMap().containsKey(tuple.getDestModuleName()) && tuple.getModuleCopyMap().get(tuple.getDestModuleName())!=vmId )){
					return;
				}
				tuple.setVmId(vmId);
				//Logger.error(getName(), "Executing tuple for operator " + moduleName);
				
				updateTimingsOnReceipt(tuple);
				
				//DEBUT DES MODIFICATIONS:
				//System.out.println("555555555555"+tuple.getDestModuleName());
				
				
				if (tuple.getTupleType()!="data" && tuple.getTupleType()!="requestVMdata" && tuple.getTupleType()!="requestVMvideo" && tuple.getTupleType()!="responseVMvideo" && tuple.getTupleType()!="responseVMdata") {
					if (moduleMapping.getModuleMapping().get(this.getName()).contains("module_data")) {
						i++;
						System.out.println("the device "+this.getName()+" in event "+i+" without data tuple");
					} 
				}
				else
				{
					i=0;	
				}
				if (tuple.getTupleType()!="video" && tuple.getTupleType()!="requestVMdata" && tuple.getTupleType()!="requestVMvideo" && tuple.getTupleType()!="responseVMvideo" && tuple.getTupleType()!="responseVMdata") {
					if (moduleMapping.getModuleMapping().get(this.getName()).contains("module_video")) {
						j++;
						System.out.println("the device "+this.getName()+ " in event "+j+ " without video tuple");
					}
				}
				else
				{
					j=0;
				}
				if (j==3) {
					
						moduleMapping.getModuleMapping().get(this.getName()).remove("module_video");
						System.out.println("the device "+this.getName()+" remove the module module_video");
						System.out.println("so the module mapping for "+this.getName()+" is"+moduleMapping.getModuleMapping().get(this.getName()));
						
						j=0;
						
				}
				if (i==3) {
						moduleMapping.getModuleMapping().get(this.getName()).remove("module_data");
						System.out.println("the device "+this.getName()+" remove the module module_data");
						System.out.println("so the module mapping for "+this.getName()+" is"+moduleMapping.getModuleMapping().get(this.getName()));
						
						i=0;
				}
				
				
				
				
				switch (tuple.getTupleType()) {
				
				
					
				case "video":
					
					if (!moduleMapping.getModuleMapping().get(this.getName()).contains("module_video")&&sendRequestV==true) {
						System.out.println("the device "+this.getName()+" recive a video tuple and he dont have module_video");
						executeTuple(ev, tuple.getDestModuleName()); //le tuple est ex�cut� sans condition
						sendRequestV=false;
						videoTupleLose++;
					}else {
						sendUp(tuple);
					}
				

					break;
					
				case "data":

					if (!moduleMapping.getModuleMapping().get(this.getName()).contains("module_data")&&sendRequestD==true) {
						System.out.println("the device "+this.getName()+" recive a data tuple and he dont have module_data           "+tuple.getSourceDeviceId());
						executeTuple(ev, tuple.getDestModuleName()); //le tuple est ex�cut� sans condition
						sendRequestD=false;
						dataTupleLose++;
					}else {
						sendUp(tuple);
					}
			

					break;
					
				
				
					case "rresponseVMvideo":
						
					
						//System.out.println("so the module mapping for "+this.getName()+" is"+moduleMapping.getModuleMapping().get(this.getName()));

					if (moduleMapping.getModuleMapping().get(this.getName()).contains("module_fog1")) {
						

						
						
							System.out.println("the device "+this.getName()+" get module_video ");
							moduleMapping.addModuleToDevice("module_video", this.getName());
							System.out.println("so the module mapping for "+this.getName()+" is"+moduleMapping.getModuleMapping().get(this.getName()));
							
						
							}

					
					break;
				case "rresponseVMdata":
					
					
					

					if (moduleMapping.getModuleMapping().get(this.getName()).contains("module_fog1")) {
						

						
						
							System.out.println("the device "+this.getName()+" get module_data ");
							moduleMapping.addModuleToDevice("module_data", this.getName());
							System.out.println("so the module mapping for "+this.getName()+" is"+moduleMapping.getModuleMapping().get(this.getName()));
							
						
							}
					break;
					
				
				default: //sinon s'il ne s'agit pas d'un tuple COMMANDE, impossible dans la topologie tel que l'�nonc� la d�crit
					executeTuple(ev, tuple.getDestModuleName()); //le tuple est ex�cut� sans condition
					//System.out.println("**envoi tupleggggggggggggggggggggggggggggggggggggggggggggggg ");


				}

				//FIN DES MODIFICATIONS
			}else if(tuple.getDestModuleName()!=null){
				
			
				
				if(tuple.getDirection() == Tuple.UP) {
					
					 
						sendUp(tuple);
						
						//System.out.println("**e+++++++++++++++++++++++++++++++++++++++++");

						
					
					
					
					
					
					
					
					
					
					
					
					
					//System.out.println("**envoi tupleggggggggggggggggggggggggggggggggggggggggggggggg ");




			}
				else if(tuple.getDirection() == Tuple.DOWN){
					if  (this.getId()==3) {
					int s=(((tuple.getSourceDeviceId()-3)%Config.nbrefog)+3);
					if(s==3)
						s=s+Config.nbrefog;
					sendDown(tuple, s);
					//System.out.println("**envoi tupleggggggggggggggggggggggggggggggggggggggggggggggg "+s);
				}
					else {
					for(int childId : getChildrenIds()) {
						sendDown(tuple, childId);
					System.out.println(this.getId());
			//		System.out.println("**envoi tupleggggggggggggggggggggggggggggggggggggggggggggggg "+childId);
					}
					}
				}
			}else{
				sendUp(tuple);
			//System.out.println("**envoi tupleggggggggggggggggggggggggggggggggggggggggggggggg ");






				
			}
		}else{
			if(tuple.getDirection() == Tuple.UP) {
			/*	if(tuple.getTupleType()=="requestVMvideo" ||tuple.getTupleType()=="requestVMdata") 
				{
					for(int childId : getChildrenIds())
						sendDown(tuple, childId);
				}*/

				 if(tuple.getTupleType()!="broadCast") {
				sendUp(tuple);
			//	System.out.println("**envoi tupleggggggggggggggggggggggggggggggggggggggggggggggg ");


				}
				




				}
			else if(tuple.getDirection() == Tuple.DOWN){
				
			/*	if  (this.getId()==4||this.getId()==5||this.getId()==6) {
						

					sendDown(tuple, tuple.getSourceDeviceId()-3);
				}*/
					

				{
				for(int childId : getChildrenIds()) {
					sendDown(tuple, childId);
				System.out.println(this.getId());}
				
				
				}
			}
		}
	
	//	System.out.println(moduleMapping.getModuleMapping());
		System.out.println("\n");


	}
	
	
	
	
	
	protected void checkCloudletCompletion() {
	boolean cloudletCompleted = false;
	List<? extends Host> list = getVmAllocationPolicy().getHostList();
	for (int i = 0; i < list.size(); i++) {
		Host host = list.get(i);
		for (Vm vm : host.getVmList()) {
			while (vm.getCloudletScheduler().isFinishedCloudlets()) {
				Cloudlet cl = vm.getCloudletScheduler().getNextFinishedCloudlet();
				if (cl != null) {
					
					cloudletCompleted = true;
					Tuple tuple = (Tuple)cl;
					TimeKeeper.getInstance().tupleEndedExecution(tuple);
					Application application = getApplicationMap().get(tuple.getAppId());
					Logger.debug(getName(), "Completed execution of tuple "+tuple.getCloudletId()+"on "+tuple.getDestModuleName());
					List<Tuple> resultantTuples;
					if(tuple.getTupleType()=="requestVMvideo"||tuple.getTupleType()=="requestVMdata") {
						resultantTuples = application.getResultantTuples(tuple.getDestModuleName(), tuple, tuple.getSourceDeviceId(), vm.getId());
						//System.out.println("#######################################");
						//System.out.println(tuple.getTupleType());
					}
					else {
						resultantTuples = application.getResultantTuples(tuple.getDestModuleName(), tuple, getId(), vm.getId());
						//System.out.println("#######################################");
					}
					for(Tuple resTuple : resultantTuples){
						resTuple.setModuleCopyMap(new HashMap<String, Integer>(tuple.getModuleCopyMap()));
						resTuple.getModuleCopyMap().put(((AppModule)vm).getName(), vm.getId());
						updateTimingsOnSending(resTuple);
						sendToSelf(resTuple);
					}
					sendNow(cl.getUserId(), CloudSimTags.CLOUDLET_RETURN, cl);
				}
			}
		}
	}
	if(cloudletCompleted)
		updateAllocatedMips(null);
}
	
	
	protected double updateCloudetProcessingWithoutSchedulingFutureEventsForce() {
		double currentTime = CloudSim.clock();
		double minTime = Double.MAX_VALUE;
		double timeDiff = currentTime - getLastProcessTime();
		double timeFrameDatacenterEnergy = 0.0;

		for (PowerHost host : this.<PowerHost> getHostList()) {
			Log.printLine();

			double time = host.updateVmsProcessing(currentTime); // inform VMs to update processing
			if (time < minTime) {
				minTime = time;
			}

			Log.formatLine(
					"%.2f: [Host #%d] utilization is %.2f%%",
					currentTime,
					host.getId(),
					host.getUtilizationOfCpu() * 100);
		}

		if (timeDiff > 0) {
			Log.formatLine(
					"\nEnergy consumption for the last time frame from %.2f to %.2f:",
					getLastProcessTime(),
					currentTime);

			for (PowerHost host : this.<PowerHost> getHostList()) {
				double previousUtilizationOfCpu = host.getPreviousUtilizationOfCpu();
				double utilizationOfCpu = host.getUtilizationOfCpu();
				double timeFrameHostEnergy = host.getEnergyLinearInterpolation(
						previousUtilizationOfCpu,
						utilizationOfCpu,
						timeDiff);
				timeFrameDatacenterEnergy += timeFrameHostEnergy;

				Log.printLine();
				Log.formatLine(
						"%.2f: [Host #%d] utilization at %.2f was %.2f%%, now is %.2f%%",
						currentTime,
						host.getId(),
						getLastProcessTime(),
						previousUtilizationOfCpu * 100,
						utilizationOfCpu * 100);
				Log.formatLine(
						"%.2f: [Host #%d] energy is %.2f W*sec",
						currentTime,
						host.getId(),
						timeFrameHostEnergy);
			}

			Log.formatLine(
					"\n%.2f: Data center's energy is %.2f W*sec\n",
					currentTime,
					timeFrameDatacenterEnergy);
		}

		setPower(getPower() + timeFrameDatacenterEnergy);

		checkCloudletCompletion();

		/** Remove completed VMs **/
		/**
		 * Change made by HARSHIT GUPTA
		 */
		/*for (PowerHost host : this.<PowerHost> getHostList()) {
			for (Vm vm : host.getCompletedVms()) {
				getVmAllocationPolicy().deallocateHostForVm(vm);
				getVmList().remove(vm);
				Log.printLine("VM #" + vm.getId() + " has been deallocated from host #" + host.getId());
			}
		}*/
		
		Log.printLine();

		setLastProcessTime(currentTime);
		return minTime;
	}

	
	
	
	
	
	protected void processOtherEvent(SimEvent ev) {

		switch(ev.getTag()){
		case FogEvents.TUPLE_ARRIVAL:
			Tuple t = (Tuple)(ev.getData());
			if(ev.getSource() != ev.getDestination()) {
				System.out.println(ev+" tuple: "+t.getTupleType()+" t="+CloudSim.clock());
				//System.out.println("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");

			}
			processTupleArrival(ev);

			break;
		case FogEvents.LAUNCH_MODULE:
			processModuleArrival(ev);
			break;
		case FogEvents.RELEASE_OPERATOR:
			processOperatorRelease(ev);
			break;
		case FogEvents.SENSOR_JOINED:
			processSensorJoining(ev);
			break;
		case FogEvents.SEND_PERIODIC_TUPLE:
			sendPeriodicTuple(ev);
			break;
		case FogEvents.APP_SUBMIT:
			processAppSubmit(ev);
			break;
		case FogEvents.UPDATE_NORTH_TUPLE_QUEUE:
			//System.out.println("-------------------UP--------------------------");
			updateNorthTupleQueue();
			//System.out.println("-------------------LEFT--------------------------");
			updateNorthTupleQueueLeft();
			//System.out.println("-------------------RIGHT--------------------------");
			updateNorthTupleQueueRight();
			break;
			
		case FogEvents.UPDATE_SOUTH_TUPLE_QUEUE:
			updateSouthTupleQueue();
			break;
		case FogEvents.ACTIVE_APP_UPDATE:
			updateActiveApplications(ev);
			break;
		case FogEvents.ACTUATOR_JOINED:
			processActuatorJoined(ev);
			break;
		case FogEvents.LAUNCH_MODULE_INSTANCE:
			updateModuleInstanceCount(ev);
			break;
		case FogEvents.RESOURCE_MGMT:
			manageResources(ev);
		default:
			break;
		}
	}
	
	
	
	
	protected void updateNorthTupleQueueRight(){
		if(!getNorthTupleQueueRight().isEmpty()){
			Tuple tuple = getNorthTupleQueueRight().poll();
			sendUpFreeLink(tuple,"right");
		}else{
			setNorthLinkBusyRight(false);
	
		}
	}
	protected void updateNorthTupleQueueLeft(){
		if(!getNorthTupleQueueLeft().isEmpty()){
			Tuple tuple = getNorthTupleQueueLeft().poll();
			sendUpFreeLink(tuple,"left");
		}else{
			setNorthLinkBusyLeft(false);

		}
	}
	
	
	
	
	public Queue<Tuple> getNorthTupleQueueLeft() {
		return northTupleQueueLeft;
	}

	public void setNorthTupleQueueLeft(Queue<Tuple> northTupleQueue) {
		this.northTupleQueueLeft = northTupleQueue;
	}
	
	public Queue<Tuple> getNorthTupleQueueRight() {
		return northTupleQueueRight;
	}

	public void setNorthTupleQueueRight(Queue<Tuple> northTupleQueue) {
		this.northTupleQueueRight = northTupleQueue;
	}
	
	
	
	void SetModulleMapping(ModuleMapping mmoduleMapping){
		 moduleMapping = mmoduleMapping;
	}
	protected ModuleMapping getModulleMapping(){
		 return moduleMapping;
	}
	
	
	
	public int getParentId2() {
		return parentId2;
	}
	public void setParentId2(int parentId) {
		this.parentId2 = parentId;
		
	}
	
	public int getParentId3() {
		return parentId3;
	}
	public void setParentId3(int parentId) {
		this.parentId3 = parentId;
	}
	public int getDataTupleLose() {
		return dataTupleLose;
	}
	public int getVideoTupleLose() {
		return videoTupleLose;
	}
}

