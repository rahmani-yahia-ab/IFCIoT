if processTupleArrival{
	if tuple.getTupleType()== donn�e{
		if this.contains(module <==> tuple donn�e){
			taitement
		}
		else {
			- recup�ration de la meilleur destination depuit le bloc
			- envoi request tuple
		}
	}
	else if tuple.getTupleType()==request{
		if this.contains(module <==> tuple request){
			-envoi response tuple avec module
		}
		else {
			routage
		}
		
		
	}
	else if tuple.getTupleType()==response{
		if tuple.getdestDeviceID=this.deviceID{
			- instalation de module
			- actualisation de la blockchain
			- envoi tuple notif pour les autre noeud 
		}
		else {
			routage
		}
		
	}
	else if tuple.getTupleType()==notif{
		actualisation de la blockchain
	
	}
	else {
		routage vers le cloud
	}
}