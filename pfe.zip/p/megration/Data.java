package p.megration;

	class Data {
		public String DeviceName;
		public int ID;
		public String ModulleName;
		public Data() {
	
		}
	}
	