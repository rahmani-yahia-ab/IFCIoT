package p.megration;

import java.util.ArrayList;
import java.util.List;


import org.fog.entities.FogDevice;


public class latancy {
		static List<FogDevice> fogDevices=new ArrayList<FogDevice>();
		public static List<Double> reqd = new ArrayList<Double>();
		public static List<Double> reqv = new ArrayList<Double>();
		public static List<Double> rspd = new ArrayList<Double>();
		public static List<Double> rspv = new ArrayList<Double>();
		
		public static void setFogDevices (List<FogDevice> FogDevices) {
			fogDevices=FogDevices;
			for(int i=1;i<=fogDevices.size();i++) {
				reqd.add(0.0);
				reqv.add(0.0);
				rspd.add(0.0);
				rspv.add(0.0);
			}
		}
		
		
		
		public static double  latancyVideo(String nameFog ) {
			double s = 0;
			for(int j=0;j<=fogDevices.size()-1;j++) {
				if (fogDevices.get(j).getName()==nameFog) {
					 s=rspv.get(j)-reqv.get(j);
				}
			}
			return s;
	
		}
		public static double  latancyData(String nameFog) {
			double s=0;
			for(int j=0;j<=fogDevices.size()-1;j++) {
				if (fogDevices.get(j).getName()==nameFog) {
					 s=rspd.get(j)-reqd.get(j);
				}
			}
			return s;
	
		}
		
		public static void setReqd(double i,String nameFog) {
			for(int j=0;j<=fogDevices.size()-1;j++) {
				if (fogDevices.get(j).getName()==nameFog) {
					reqd.set(j, i);
				}
			}
			
		}
		
		public static void setReqv(double i,String nameFog) {
			for(int j=0;j<=fogDevices.size()-1;j++) {
				if (fogDevices.get(j).getName()==nameFog) {
					reqv.set(j, i);
				}
			}		
		}
		
		public static void setRspd(double i,String nameFog) {
			for(int j=0;j<=fogDevices.size()-1;j++) {
				if (fogDevices.get(j).getName()==nameFog) {
					rspd.set(j, i);
				}
			}		
		}
		
		public static void setRspv(double i,String nameFog) {
			for(int j=0;j<=fogDevices.size()-1;j++) {
				if (fogDevices.get(j).getName()==nameFog) {
					rspv.set(j, i);
				}
			} 
		}
	}
	